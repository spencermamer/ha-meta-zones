
DOMAIN = "zone_sensors"
CONF_METAZONES = "metazones"
CONF_LABELS = "labels"
